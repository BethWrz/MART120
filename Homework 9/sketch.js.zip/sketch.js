// JavaScript Document

	function setup()
		{
		createcanvas (500,600);
		}

		function draw()
		{
			background(120);
		}
